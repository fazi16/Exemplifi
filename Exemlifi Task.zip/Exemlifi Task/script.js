
function toggleDropdown() {
    var productsMenu = document.getElementById("products-menu");
    productsMenu.classList.toggle("show");
}


window.onclick = function(event) {
    if (!event.target.closest('.dropdown-toggle') && !event.target.closest('.mega-menu')) {
        var dropdowns = document.getElementsByClassName("mega-menu");
        for (var i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
};
